
import React from 'react';
import { PackagingMaterialsManagement } from '../../components/packaging/PackagingMaterialsManagement';

export function PackagingManagementPage() {
    return <PackagingMaterialsManagement />;
}
