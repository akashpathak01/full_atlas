
import React from 'react';
import { PackagingOrders } from '../../components/packaging/PackagingOrders';

export function PackagingOrdersPage() {
    return <PackagingOrders />;
}
