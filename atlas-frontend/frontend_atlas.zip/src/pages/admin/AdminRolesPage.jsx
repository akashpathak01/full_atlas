import React from 'react';
import { RolesManager } from '../../components/roles/RolesManager';

export function AdminRolesPage() {
    return <RolesManager />;
}
