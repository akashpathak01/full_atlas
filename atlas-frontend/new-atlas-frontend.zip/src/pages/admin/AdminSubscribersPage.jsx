import React from 'react';
import { SubscribersManager } from '../../components/subscribers/SubscribersManager';

export function AdminSubscribersPage() {
    return <SubscribersManager />;
}
