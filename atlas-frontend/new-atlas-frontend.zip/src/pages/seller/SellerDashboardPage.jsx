import React from 'react';
import { SellerDashboard } from '../../components/dashboard/SellerDashboard';

export function SellerDashboardPage() {
    return (
        <SellerDashboard />
    );
}
