
import React from 'react';
import { PackagingReports } from '../../components/packaging/PackagingReports';

export function PackagingReportsPage() {
    return <PackagingReports />;
}
