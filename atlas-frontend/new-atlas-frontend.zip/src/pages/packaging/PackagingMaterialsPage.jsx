
import React from 'react';
import { PackagingMaterials } from '../../components/packaging/PackagingMaterials';

export function PackagingMaterialsPage() {
    return <PackagingMaterials />;
}
