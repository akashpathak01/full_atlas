
import React from 'react';
import { PackagingDashboard } from '../../components/packaging/PackagingDashboard';

export function PackagingDashboardPage() {
    return <PackagingDashboard />;
}
